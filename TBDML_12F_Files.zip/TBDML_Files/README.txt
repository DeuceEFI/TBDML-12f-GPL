File descriptions:

1) bin_jb8_xx.zip				

binary of the HC08JB8 firmware
you need to download this into internal flash of the HC08JB before you use the 
interface for the first time

2) bin_tbdml_dll_xx.zip

binary of the TBDML.DLL
this is what you need if you are planning to use the interface from another program

3) bin_tbdml_gdi_dll_xx.zip 		

GDI interface DLL for MW Hiwave debugger
you need this file if you are planning to use the interface with the MW debugger

4) bin_tbdml_win_driver_xx.zip 

compilation of different DLLs and the USB driver needed to install the interface
as a device under Windows

5) libusb-win32-device-bin-0.1.10.1.tar.gz 

original distribution of the USB driver I am using to talk to the interface

6) license_gpl.txt 

license - read it before you use any of the files to make sure you undestand and
agree with all the terms

7) sw_jb8_xx.zip 

source code of the firmware for the HC08JB8

8) sw_tbdml_dll_xx.zip 

source code of the TBDML.DLL

9) tbdml_manual_xx.pdf 

user's manual

10) tbdml_pcb_xx.zip 

gerber files for the PCB



Changes:

v11d: 	added tbdml.exp and tbdml.lib to bin_tbdml_dll_11.zip 
	added missing tbdml_hwdesc.h into sw_tbdml_dll_11.zip 
	added the 00readme.txt for better orientation

v11e:	C9 and C12 did not agree between schematic and PCB in the doc. Changed the schematic.

v11f:   Behaviour of the debugger was not correct during external target reset. 
	New DLL for Hi-wave and new firmware for the cable generated.

v11g:	Added CPU selection menu for old HC12 devices

v12:	Changed reported features in the GDI DLL to tell the debugger to use SW breakpoints when possible (i.e. when debugging from RAM)

v12b:	Fixed a bug in the GDI DLL (word (2 bytes) writes and reads from misaligned addresses did not work properly). The GDI DLL is now version 1.4.

v12c:	Expanded the set speed dialogue - it now offers a possibility to set the ratio between crystal and BDM clock frequencies

v12d:   Improved the connection sequence to improve connecting to a secured target

v12e:   Fix in version 1.2d introduced a bug - it was not possible to talk to a device which supports BDM SYNC, is in normal mode and contains invalid user code

v12f:	New version of GDI DLL - now it remembers the selected HC12 derivative even through debugger shutdown.

